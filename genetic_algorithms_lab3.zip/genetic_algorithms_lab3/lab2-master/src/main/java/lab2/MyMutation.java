package lab2;

import org.uncommons.watchmaker.framework.EvolutionaryOperator;

import java.util.List;
import java.util.Random;

public class MyMutation implements EvolutionaryOperator<double[]> {
    private final double mutationProbability; // Probability of mutation

    public MyMutation(double mutationProbability) {
        this.mutationProbability = mutationProbability;
    }

    public List<double[]> apply(List<double[]> population, Random random) {
        for (double[] individual : population) {
            for (int i = 0; i < individual.length; i++) {
                // Applying uniform mutation to each gene with the specified probability
                if (random.nextDouble() < mutationProbability) {
                    // Generating a random value within the range of [-5, 5] to replace the current gene
                    individual[i] = -5.0 + 10.0 * random.nextDouble();
                }
            }
        }
        return population;
    }
}
