package lab2;

import org.uncommons.watchmaker.framework.operators.AbstractCrossover;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MyCrossover extends AbstractCrossover<double[]> {
    protected MyCrossover() {
        super(1);
    }

    protected List<double[]> mate(double[] p1, double[] p2, int i, Random random) {
        ArrayList<double[]> children = new ArrayList<>();

        double[] child = new double[p1.length];
        double alpha = random.nextDouble(); // Parameter for controlling the crossover
        for (int j = 0; j < p1.length; j++) {
            // Performing arithmetic crossover
            child[j] = alpha * p1[j] + (1 - alpha) * p2[j];
        }

        children.add(child);
        return children;
    }
}
